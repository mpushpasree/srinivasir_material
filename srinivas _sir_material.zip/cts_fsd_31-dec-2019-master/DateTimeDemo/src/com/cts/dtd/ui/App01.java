package com.cts.dtd.ui;

import java.util.Date;

public class App01 {

	public static void main(String[] args) {
		Date obj = new Date();
		System.out.println(obj);

	}

}
