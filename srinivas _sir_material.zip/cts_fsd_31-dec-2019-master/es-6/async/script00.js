/*console.log('Hello Everybody');
console.log('Hai One and All');*/

setTimeout(()=>{console.log('Hello Everybody');},3000);
setTimeout(()=>{console.log('Hai One and All');},500);

