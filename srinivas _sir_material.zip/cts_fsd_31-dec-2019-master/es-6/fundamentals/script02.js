x = 90;
y = 10;
z="10"

//arithemtic oprations
console.log(x+y);
console.log(x-y);
console.log(x*y);
console.log(x/y);
console.log(x%y);


//logical operations
console.log(x===y);
console.log(x==y);
console.log("-----------------------");

console.log(z===y);
console.log(z==y);

console.log(x<y);
console.log(x>y);
console.log(x<=y);
console.log(x>=y);
console.log(x!=y);