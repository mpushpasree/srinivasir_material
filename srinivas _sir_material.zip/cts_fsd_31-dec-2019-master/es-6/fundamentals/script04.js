x = 2;
y = 5;

console.log(Math.pow(x,y));
console.log(Math.log(x));
console.log(Math.exp(x));
console.log(Math.sqrt(x));

console.log(Math.PI);
console.log(Math.sin(Math.PI));
console.log(Math.cos(Math.PI));
console.log(Math.tan(Math.PI));
