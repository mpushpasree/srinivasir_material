//we want to print a single line of string.
console.log("Hello World! Welcome To Javascript [ES6]");