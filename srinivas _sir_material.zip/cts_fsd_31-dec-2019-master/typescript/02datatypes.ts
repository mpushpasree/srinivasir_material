var v1 : number = 10;
var v2 : string = "Hello";
var v3 : boolean = true;
var v4 : string;
var v5 : string = null;

console.log(v1);
console.log(v2);
console.log(v3);
console.log(v4);
console.log(v5);

console.log("The value of v1 = " + v1 + ", value of v2 = " + v2 + " value of v3 = " + v3);
// Interpolation
console.log(`The value of v1 = ${v1}, value of v2 = ${v2}, value of v3 = ${v3}`);
