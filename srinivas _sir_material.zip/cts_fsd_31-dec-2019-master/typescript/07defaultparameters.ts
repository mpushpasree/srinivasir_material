// Default Parameters
function add(n1:number=10, n2:number=35) {
    return n1+n2;
}

console.log(add());
console.log(add(5,6));
console.log(add(7));
