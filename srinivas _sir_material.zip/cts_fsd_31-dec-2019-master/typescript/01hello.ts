var msg : string = "Welcome to TypeScript 3.7.5";
console.log(msg);

// demonstrating "any" datatype
var a : any;
a = 10;
console.log(typeof(a));
console.log(a*a);
a = "abc";
console.log(typeof(a));
console.log(a+a);