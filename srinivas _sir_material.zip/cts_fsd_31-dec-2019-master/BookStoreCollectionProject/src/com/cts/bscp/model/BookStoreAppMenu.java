package com.cts.bscp.model;

public enum BookStoreAppMenu {
	ADD,REMOVE,SEARCH,LIST,QUIT;
}
